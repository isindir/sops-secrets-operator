# sops-secrets-operator

Helm chart deploys sops-secrets-operator

## Source Code

* <https://github.com/isindir/sops-secrets-operator.git>

## TL;DR;

```console
$ kubectl create namespace sops

$ kubectl apply -f deploy/crds/isindir_v1alpha1_sopssecret_crd.yaml

$ helm repo add sops https://isindir.github.io/sops-secrets-operator/

$ helm upgrade --install sops sops/sops-secrets-operator \
  --namespace sops -f custom.values.yaml
```

> where `custom.values.yaml` must customise deployment and configure access to Cloud KMS

The same chart is also published to an OCI registry (starting with chart version `0.29.3`), e.g. to use a registry
pull-through cache:

```console
$ helm upgrade --install sops oci://quay.io/isindir/charts/sops-secrets-operator \
  --namespace sops -f custom.values.yaml
```

> add `--version <chart version>` to pin a chart version with either source

* AWS is supported via `kiam` namespace and pod annotations or via [IAM roles for service accounts](https://docs.aws.amazon.com/eks/latest/userguide/specify-service-account-role.html)
* GCP is supported via service account secret which allows decryption using GCP KMS
* GPG is supported via secrets with GPG configuration
* Azure is supported via a Service principal plus a secret
* Vault is supported via vault agent injections
* Age is supported via mounting secret and defining environment variable

## Introduction

This chart bootstraps a [sops-secrets-operator](https://github.com/isindir/sops-secrets-operator.git) deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Installing the Chart

### AWS

* Deploy [kiam](https://github.com/uswitch/kiam) using [kiam chart](https://github.com/helm/charts/tree/master/stable/kiam)
  * Alternatively [kube2iam](https://github.com/jtblin/kube2iam)
  * Or provide credentials to perform AWS KMS operations
* Create IAM assume role which allows to use KMS key for decryption
* Create Kubernetes namespace for operator deployment, with kiam annotation
* Apply `sops-secrets-operator` CRD
* Deploy helm chart

### GCP

* Create GCP Service Account which allows to use KMS to decrypt
* Either put the GCP Service Account JSON file in your custom values.yaml file or create a Kubernetes Secret with the same information and put the name of that secret in your values.yaml. Enable GCP in the Helm Chart by setting `gcp.enabled: true` in values.yaml.

* Create custom values file in a following format:

```yaml
gcp:
  enabled: true
  svcAccSecret: |-
    {
      "type": "service_account",
      ...
    }
```

or

```yaml
gcp:
  enabled: true
  existingSecretName: gcp-sa-existing-secret-name
```

* Create Kubernetes namespace for operator deployment
* Apply `sops-secrets-operator` CRD
* Deploy helm chart specifying extra values file

### Azure

* Create a KeyVault if you don't have one already
* Create a Key in that KeyVault
* Create Service principal with permissions to use the key for Encryption/Decryption
  * follow the [SOPS documentation](https://github.com/mozilla/sops#encrypting-using-azure-key-vault)
* Either put Tenant ID, Client ID and Client Secret for the Service Principal in your custom values.yaml file or create a Kubernetes Secret with the same information and put the name of that secret in your values.yaml. Enable Azure in the Helm Chart by setting `azure.enabled: true` in values.yaml.

### Age

* Create age `keys.txt` file
* Create Kubernetes secret using `keys.txt`
* When deploying helm chart use `extraEnv` value to speicify environment variable `SOPS_AGE_RECIPIENTS` and `secretsAsFiles` value to mount `keys.txt`

For reference see:

* [Age encryption tool](https://github.com/FiloSottile/age)
* [sops section on how to encrypt](https://github.com/mozilla/sops#22encrypting-using-age)
* Also see: [Local testing using age](docs/age/README.md)

## Metrics

Metrics are disabled by default (the operator metrics listener is switched off). Enable them with
`--set metrics.enabled=true`, this opens the metrics listener on `metrics.port` (default `8080`) and creates a
metrics Service (`<chart fullname>-metrics`) exposing it on the `metrics` port.

To scrape the Service with [prometheus-operator](https://github.com/prometheus-operator/prometheus-operator), also
enable the ServiceMonitor (requires prometheus-operator CRDs in the cluster) and add the labels your Prometheus
selects ServiceMonitors by:

```yaml
metrics:
  enabled: true
  serviceMonitor:
    enabled: true
    additionalLabels:
      release: prometheus
```

To scrape it with the [VictoriaMetrics operator](https://github.com/VictoriaMetrics/operator) instead (or side by side),
enable the VMServiceScrape (requires VictoriaMetrics operator CRDs in the cluster):

```yaml
metrics:
  enabled: true
  vmServiceScrape:
    enabled: true
```

> **Note:** if the VictoriaMetrics operator also converts prometheus-operator ServiceMonitors, enable only one of
> `serviceMonitor` / `vmServiceScrape` for it, otherwise the operator metrics are scraped twice.

Besides the standard controller-runtime metrics, the operator exposes:

* `sopssecrets_reconcilation_successes_total` - successful SopsSecret reconciliations
* `sopssecrets_reconcilation_failures_total` - failed SopsSecret reconciliations
* `sopssecrets_reconcilation_suspends_total` - skipped reconciliations of suspended SopsSecrets

> **Note:** since chart `0.30.0` the metrics listener is off unless `metrics.enabled` is `true` (previously the
> operator always listened on `:8080`), and ServiceMonitor labels moved from `metrics.additionalLabels` to
> `metrics.serviceMonitor.additionalLabels`.

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
$ helm uninstall sops
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the Sops-secrets-operator chart and their default values.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Node affinity for pod assignment |
| azure | object | `{"clientId":"","clientSecret":"","enabled":false,"existingSecretName":"","tenantId":""}` | Azure KeyVault configuration section |
| azure.clientId | string | `""` | ClientID (Application ID) of Azure Service Principal to use |
| azure.clientSecret | string | `""` | Client Secret of Azure Service Principal |
| azure.enabled | bool | `false` | if true Azure KeyVault will be used |
| azure.existingSecretName | string | `""` | Name of a pre-existing secret containing Azure Service Principal Credentials (ClientID, ClientSecret, TenantID) |
| azure.tenantId | string | `""` | TenantID of Azure Service principal to use |
| defaultEnforceOwnership | bool | `false` | Default behavior for enforcing ownership of pre-existing secrets. When enabled, the controller will take ownership of secrets that exist but are not owned by the SopsSecret. This is useful after backup restore operations where secrets may exist with stale owner references. Can be overridden per-SopsSecret with spec.enforceOwnership. |
| extraEnv | list | `[]` | A list of additional environment variables |
| extraVolumeMounts | list | `[]` | Additional volume mounts for the operator container (not the GPG init container) |
| extraVolumes | list | `[]` | Additional volumes for the operator pod, e.g. CSI secrets store volume for Azure Key Vault |
| fullnameOverride | string | `""` | Overrides auto-generated long resource name |
| gcp | object | `{"enabled":false,"existingSecretName":"","svcAccSecret":"","svcAccSecretCustomName":""}` | GCP KMS configuration section |
| gcp.enabled | bool | `false` | Node labels for operator pod assignment |
| gcp.existingSecretName | string | `""` | Name of a pre-existing secret containing GCP service account secret json payload |
| gcp.svcAccSecret | string | `""` | If `gcp.enabled` is `true`, this value must be specified as GCP service account secret json payload |
| gcp.svcAccSecretCustomName | string | `""` | Name of the secret to create - will override default secret name if specified |
| gpg | object | `{"enabled":false,"secret1":"gpg1","secret2":"gpg2"}` | GPG configuration section |
| gpg.enabled | bool | `false` | If `true` GCP secret will be created from provided value and mounted as environment variable |
| gpg.secret1 | string | `"gpg1"` | Name of the secret to create - will override default secret name if specified |
| gpg.secret2 | string | `"gpg2"` | Name of the secret to create - will override default secret name if specified |
| healthProbes.liveness | object | `{"initialDelaySeconds":15,"periodSeconds":20}` | Liveness probe configuration |
| healthProbes.port | int | `8081` | The address the probe endpoint binds to. (default ":8081") |
| healthProbes.readiness | object | `{"initialDelaySeconds":5,"periodSeconds":10}` | Readiness probe configuration |
| image.pullPolicy | string | `"Always"` | Operator image pull policy |
| image.repository | string | `"quay.io/isindir/sops-secrets-operator"` | Operator image name |
| image.tag | string | `"0.22.4"` | Operator image tag |
| imagePullSecrets | list | `[]` | Secrets to pull image from private docker repository |
| initImage.pullPolicy | string | `"Always"` | Init container image pull policy |
| initImage.repository | string | `"public.ecr.aws/ubuntu/ubuntu"` | Init container image name |
| initImage.tag | string | `"26.04"` | Init container image tag |
| kubeconfig | object | `{"enabled":false,"path":null}` | Paths to a kubeconfig. Only required if out-of-cluster. |
| logging | object | `{"development":false,"encoder":"json","level":"info","stacktraceLevel":"error","timeEncoding":"iso8601"}` | Logging configuration section suggested values Development Mode (encoder=consoleEncoder,logLevel=Debug,stackTraceLevel=Warn). Production Mode (encoder=jsonEncoder,logLevel=Info,stackTraceLevel=Error) (default) |
| logging.development | bool | `false` | Zap Development Mode enabled |
| logging.encoder | string | `"json"` | Zap log encoding (one of 'json' or 'console') |
| logging.level | string | `"info"` | Zap Level to configure the verbosity of logging. Can be one of 'debug', 'info', 'error', or any integer value > 0 which corresponds to custom debug levels of increasing verbosity |
| logging.stacktraceLevel | string | `"error"` | Zap Level at and above which stacktraces are captured (one of 'info', 'error'). |
| logging.timeEncoding | string | `"iso8601"` | Zap time encoding (one of 'epoch', 'millis', 'nano', 'iso8601', 'rfc3339' or 'rfc3339nano'). Defaults to 'epoch'. |
| metrics.enabled | bool | `false` | Enable prometheus metrics: operator metrics listener, container port and metrics Service. When disabled, the operator metrics listener is switched off. |
| metrics.port | int | `8080` | Metrics listener, container and Service port (no effect while metrics are disabled) |
| metrics.serviceMonitor.additionalLabels | object | `{}` | Additional labels for ServiceMonitor (replaces removed `metrics.additionalLabels`) |
| metrics.serviceMonitor.enabled | bool | `false` | Create prometheus-operator ServiceMonitor scraping the metrics Service (requires `metrics.enabled` and prometheus-operator CRDs) |
| metrics.vmServiceScrape.additionalLabels | object | `{}` | Additional labels for VMServiceScrape |
| metrics.vmServiceScrape.enabled | bool | `false` | Create VictoriaMetrics operator VMServiceScrape scraping the metrics Service (requires `metrics.enabled` and VictoriaMetrics operator CRDs), can be enabled side by side with `metrics.serviceMonitor` |
| nameOverride | string | `""` | Overrides auto-generated short resource name |
| namespaceOverride | string | `""` | Overrides the release namespace rendered into metadata. Defaults to the release namespace when empty. Useful for GitOps tooling (e.g. Kustomize/ArgoCD) that consumes `helm template` output. |
| namespaced | bool | `false` | If set - operator will watch SopsSecret resources only in operator namespace |
| nodeSelector | object | `{}` | Node selector to use for pod configuration |
| podAnnotations | object | `{}` | Annotations to be added to operator pod |
| podLabels | object | `{}` | Labels to be added to operator pod |
| rbac.enabled | bool | `true` | Create and use RBAC resources |
| replicaCount | int | `1` | Deployment replica count - should not be modified |
| requeueAfter | int | `5` | Requeue failed reconciliation in minutes (min 1). (default 5) |
| resources | object | `{}` | Operator container resources |
| secretsAsEnvVars | list | `[]` | configure custom secrets to be used as environment variables at runtime, see values.yaml |
| secretsAsFiles | list | `[]` | configure custom secrets to be mounted at runtime, see values.yaml |
| securityContext.container | object | `{"capabilities":{"add":["NET_BIND_SERVICE"],"drop":["all"]},"customContainerSecurityContext":{},"enabled":false}` | container/initContainer |
| securityContext.container.capabilities | object | `{"add":["NET_BIND_SERVICE"],"drop":["all"]}` | capabilities |
| securityContext.container.customContainerSecurityContext | object | `{}` (uses preconfigured defaults above) | Custom container securityContext override. When non-empty and container.enabled is true, this replaces the preconfigured container securityContext entirely. |
| securityContext.container.enabled | bool | `false` | enables securityContext capabilities feature in containers |
| securityContext.customPodSecurityContext | object | `{}` (uses preconfigured defaults above) | Custom pod securityContext override. When non-empty and securityContext.enabled is true, this replaces the preconfigured pod securityContext entirely. |
| securityContext.enabled | bool | `false` | Enable securityContext |
| securityContext.fsGroup | int | `13001` | fs group |
| securityContext.runAsGroup | int | `13001` | GID to run as |
| securityContext.runAsNonRoot | bool | `true` | Enable kubelet validation for using root user to run container |
| securityContext.runAsUser | int | `13001` | UID to run as |
| securityContext.seccompProfileName | string | `""` | if seccompProfile.type is set to Localhost, set localhostProfile to value of seccompProfileName (user must specify value) |
| securityContext.seccompProfileType | string | `"RuntimeDefault"` | seccompProfile.type |
| serviceAccount.annotations | object | `{}` | Annotations to be added to the service account |
| serviceAccount.enabled | bool | `true` |  |
| serviceAccount.name | string | `""` | Custom service account name to use instead of automatically generated name (if enabled - chart will generate SA, if not enabled - will use preconfigured) |
| tolerations | list | `[]` | Tolerations to be applied to operator pod |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example,

Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,

> **Tip**: You can use the default [values.yaml](values.yaml)
